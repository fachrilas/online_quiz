<?php

echo "know it all page";
?>
