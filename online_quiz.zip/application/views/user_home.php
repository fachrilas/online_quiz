<?
include_once 'template/sidebar_enduser.php';
?>
