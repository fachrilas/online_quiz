<div class="row">
    <div class="col-sm-2">
        <nav class="nav-sidebar">
            <ul class="nav">
                <li><a href="<?=base_url().'user/children_home'?>">Home</a></li>
                <li><a href="<?=base_url().'user/view_assign_quiz'?>">See assigned Quiz</a></li>
                <li><a href="<?=base_url().'user/children_profile'?>">View Profile</a></li>
                
            </ul>
        </nav>
    </div>
</div>