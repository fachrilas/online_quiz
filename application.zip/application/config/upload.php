<?php

$config['upload_path'] = './uploads/';
$config['allowed_types'] = '*';
$config['overwrite']  = false;
$config['remove_spaces']  = true;
?>
