<?php

echo "test FAQ page";
?>
