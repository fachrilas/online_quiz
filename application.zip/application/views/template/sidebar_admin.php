<div class="row">
    <div class="col-mid-2">
        <nav class="nav-sidebar">
            <ul class="nav">
                <li><a href="<?=base_url().'user/admin_home'?>">Home</a></li>
                <li><a href="<?=base_url().'admin/add_question'?>">Add Question</a></li>
                <li><a href="<?=base_url().'quiz/select_level_quiz_detail'?>">View Quiz</a></li>
                <li><a href="<?=base_url().'user/view_user'?>">View Users</a></li>
            </ul>
        </nav>
    </div>
</div>