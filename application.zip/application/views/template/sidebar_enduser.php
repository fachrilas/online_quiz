<div class="row">
    <div class="col-md-5">
        <nav class="nav-sidebar">
            <ul class="nav">
                <li><a href="<?=base_url().'user/user_home'?>">Home</a></li>
                <li><a href="<?=base_url().'user/view_children'?>">View Children</a></li>
                <li><a href="<?=base_url().'user/add_child'?>">Add Child</a></li>
                <li><a href="<?=base_url().'user/review_results'?>">Review Results</a></li>
                <li><a href="<?=base_url().'user/assign_quiz'?>">Assign Quiz</a></li>
            </ul>
        </nav>
    </div>
</div>