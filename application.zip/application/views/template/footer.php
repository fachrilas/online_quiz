</div>
<div class="container">
    <div class="row footer-div">
        <div class="col-md-3" style="padding-top: 9px;padding-bottom: 9px;color: white;">
            <a href="<?=base_url().'static/contact_us'?>" class="footer_link">Contact Us</a>
        </div>
        <div class="col-md-3" style="padding-top: 9px;padding-bottom: 9px;color: white;">
            <a href="<?=base_url().'static/terms_of_use'?>" class="footer_link">Terms of Use</a>
        </div>
        <div class="col-md-3" style="padding-top: 9px;padding-bottom: 9px;color: white;">
            <a href="<?=base_url().'static/faq'?>" class="footer_link">FAQ</a>
        </div>
        <div class="col-md-3" style="padding-top: 9px;padding-bottom: 9px;color: white;">
            <a href="<?=base_url().'static/about_us'?>" class="footer_link">About Us</a>
        </div>
    </div>
    <div class="row" style="padding-left: 6px;padding-bottom: 2px;"><i>Last updated on December 31, 2013</i></div>
</div>

<body>
</html>
