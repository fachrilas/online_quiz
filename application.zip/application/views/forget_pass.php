<div class="container">
    <div class="row" style="margin-top: 20px; ">
        <div class="col-md-11 col-md-offset-0" style="width: 97%;">
            
                   <div class="panel panel-default">
                <div class="panel-heading">
                <h3 class="panel-title">Fogot password</h3>
                </div>
                <div class="panel-body">
                    <form class="form-inline" action="PassGet" method="post" role="form">
  <div class="col-xs-4">
    <label class="sr-only" for="exampleInputEmail2">Email address</label>
    <input type="email" class="form-control" name="email" id="exampleInputEmail2" placeholder="Enter email" required>
  </div>
  <button type="submit" class="btn btn-info">Submit</button>
</form>
                    
                    
                    
                </div>
            </div>
            </div>
        </div>
  
</div>