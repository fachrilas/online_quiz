<div style="margin-top: 50px;"></div>
<div class="container outer-container" >
    <div class="row blackboard_container" >
        <div class="blackboard row" style="">
            <div class="col-md-9 right-side">
                <div class="row promotion-container" >
                    <div class="heading">
                        <h1>STAR PROMOTION THIS MONTH</h1>
                    </div>
                    <div class="promotion-text">
                        purchase topical practice papers and examination papers for one level at a low price of $9.99
                    </div>
                </div>
                <div class="about-us">
                    <h1>ABOUT US</h1>
                </div>
                <div class="row about-us-container">
                    <div class="col-md-4 about-us-left">
                        lorem ipuaadfasd df asdf asdf asdf asf asdfasf asdf asdf as df asd fas dfasdf as df asdfas df asdf asdf as f
                    </div>
                    <div class="col-md-8 about-us-right">
                        lorem ipuaadfasd df asdf asdf asdf asf asdfasf asdf asdf as df asd fas dfasdf as df asdfas df asdf asdf as f
                    </div>
                </div>
            </div>
            <div class="col-md-3 left-side"></div>
        </div>
    </div>
</div>
